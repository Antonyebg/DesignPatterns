package br.com.strategyExercicio;

public class Bitcoin implements FormaPagamento{

    @Override
    public void pagamento(String dsPagamento) {
        System.out.println("Forma Pagamento: Selecionou Bitcoin");
    }
    
}
