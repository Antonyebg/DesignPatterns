package br.com.strategyExercicio;

public class CartaoCredito implements FormaPagamento{

    @Override
    public void pagamento(String dsPagamento) {
        
        System.out.println("Forma Pagamento: Selecionou CartaoCredito");
        
    }


    
}
