package br.com.strategyExercicio;


public interface FormaPagamento {

void pagamento(String dsPagamento);
    
}
