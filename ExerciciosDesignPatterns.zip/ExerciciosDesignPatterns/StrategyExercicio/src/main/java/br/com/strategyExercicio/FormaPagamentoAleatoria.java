
package br.com.strategyExercicio;

public class FormaPagamentoAleatoria implements FormaPagamento{

    @Override
    public void pagamento(String dsPagamento) {
        
        System.out.println("Forma de Pagamento: 2 bolacha trakinas e 1 suco de maracuja");
        
    }
    
}
