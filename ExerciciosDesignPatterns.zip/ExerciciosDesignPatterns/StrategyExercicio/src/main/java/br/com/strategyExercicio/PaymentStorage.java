package br.com.strategyExercicio;


public class PaymentStorage {
    
    public void store(String dsPagamento, FormaPagamento formaPagamento) {
        formaPagamento.pagamento(dsPagamento);
    }
    
}
