package br.com.composite_exercicio;


public interface Box {
    
    double calculatePrice();
    
}
