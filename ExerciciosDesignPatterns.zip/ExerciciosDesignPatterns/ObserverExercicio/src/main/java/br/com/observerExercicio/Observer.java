package br.com.observerExercicio;

public interface Observer {
    void update();
}
