package br.com.factorymethodexercicio.Burguer.Angus;

import br.com.factorymethodexercicio.Burguer.ControllerAngus;
import br.com.factorymethodexercicio.Burguer.ViewBurguer;

public class AngusController extends ControllerAngus{


    @Override
    protected ViewBurguer createViewEngine(){
    return new AngusViewEngine();
    }
    
}
