package br.com.factorymethodexercicio;

public class FactoryMethodExercicio {

    public static void main(String[] args) {
        
         new BurguerController().listProducts();
        
    }
}
