package br.com.factorymethodexercicio;

import br.com.factorymethodexercicio.Burguer.Angus.AngusController;
import br.com.factorymethodexercicio.Burguer.ControllerAngus;
import java.util.HashMap;
import java.util.Map;

public class BurguerController extends ControllerAngus{

public void listProducts(){
    //aqui pega os dados do banco;
    
       String nome = "Hamburguer Angus";
       
        //context é´populado pelos dados do BD;
        
        montarBurguer(nome);
   
    }
    
}
