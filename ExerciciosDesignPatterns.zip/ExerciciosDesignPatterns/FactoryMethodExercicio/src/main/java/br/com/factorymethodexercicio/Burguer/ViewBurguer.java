package br.com.factorymethodexercicio.Burguer;

import java.util.Map;

public interface ViewBurguer {

String montarBurguer(String burguerName);
    
}
