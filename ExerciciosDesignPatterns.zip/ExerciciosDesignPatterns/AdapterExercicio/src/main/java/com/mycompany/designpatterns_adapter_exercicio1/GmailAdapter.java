package com.mycompany.designpatterns_adapter_exercicio1;

import com.mycompany.designpatterns_adapter_exercicio2.GmailClient;

public class GmailAdapter implements EmailProvider {
    private GmailClient gmailClient;

    public GmailAdapter() {
        this.gmailClient = new GmailClient();
    }

    @Override
    public void connect() {
        gmailClient.login();
    }

    @Override
    public void fetchEmails() {
        gmailClient.getEmails();
    }
}