package com.mycompany.designpatterns_adapter_exercicio1;

public interface EmailProvider {

    void connect();

    void fetchEmails();
}
