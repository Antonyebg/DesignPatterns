package com.mycompany.designpatterns_adapter_exercicio1;

public class AdapterExemplo {

    public static void main(String[] args) {
        EmailProvider gmailAdapter = new GmailAdapter();
        EmailClient emailClient = new EmailClient(gmailAdapter);
        emailClient.checkEmails();
    }
}
