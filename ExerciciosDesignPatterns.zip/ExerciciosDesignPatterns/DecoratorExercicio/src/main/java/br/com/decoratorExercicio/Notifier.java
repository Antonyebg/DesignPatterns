
package br.com.decoratorExercicio;

public class Notifier implements NotifierInterface {

    @Override
    public void write(String data) {
        System.out.println("Status " + data);
    }


    
}
