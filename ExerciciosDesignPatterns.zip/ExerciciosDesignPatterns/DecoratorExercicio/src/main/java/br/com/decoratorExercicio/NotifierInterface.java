package br.com.decoratorExercicio;

public interface NotifierInterface {

    void write(String data);
    
}
