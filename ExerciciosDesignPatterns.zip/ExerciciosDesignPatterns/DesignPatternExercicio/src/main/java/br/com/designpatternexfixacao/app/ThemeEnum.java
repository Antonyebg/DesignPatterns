
package br.com.designpatternexfixacao.app;


public enum ThemeEnum {
    
    GANHO_MASSA,
    PERCA_PESO
    
}
