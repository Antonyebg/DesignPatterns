package br.com.designpatternexfixacao.percaPeso;

import br.com.designpatternexfixacao.abstrasctFactory.Button;


public class perdaPesoButton implements Button {

    @Override
    public void render() {
    
        System.out.println("Selecionou Perca de Peso!!!");
        
    }
    
}
