package br.com.designpatternexfixacao.abstrasctFactory;


public interface TextBox extends Widget{
    
}
